package com.actionForm;

import org.apache.struts.action.ActionForm;

public class ReaderTypeForm extends ActionForm {
    private Integer id;
    private String name;
    private int number;
    public ReaderTypeForm(){
    }
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public int getNumber() {
        return number;
    }

}
